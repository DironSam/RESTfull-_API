# RESTful-API
This is written using nodejs.
Run the program on terminal.
seperate json file ("oauth_data_collection.json") is given to generate POST and GET request automatically. You can import that
to postman or Advanced Rest Client. 
